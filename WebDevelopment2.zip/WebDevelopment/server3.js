const express = require('express');
const path = require('path');
const { engine } = require('express-handlebars');

const app = express();
const port = 3000;

// Set up Handlebars as the view engine
app.engine('hbs',engine({ extname: '.hbs'
 })); // Specify .hbs as the extension
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files (like CSS) from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Define the root route to render "index.hbs"
app.get('/', (req, res) => {
    const headerData = {
        title: 'Cook & Chill',
        homeText: 'Home',
        aboutText: 'About',
        contactText: 'Contact Us',
        loginText: 'Login',
        signUpText: 'Sign Up'
    };

    res.render('index', { headerData });
});

// Start the server
app.listen(port, () => {
    console.log(`App running on http://localhost:${port}`);
});
