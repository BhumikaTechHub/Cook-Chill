const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware to serve static files (CSS, JS, Images, JSON, HTML)
app.use(express.static(path.join(__dirname, 'public')));

// Route to serve the homepage
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'homepage.html'));
});

// Routes for other static HTML pages
app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

app.get('/chill1', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'chill1.html'));
});

app.get('/chill2', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'chill2.html'));
});

app.get('/chill3', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'chill3.html'));
});

app.get('/contact-us', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'contact-us.html'));
});

app.get('/cook1', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cook1.html'));
});

app.get('/cook2', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cook2.html'));
});

app.get('/cook3', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cook3.html'));
});

app.get('/cook4', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cook4.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/personal', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'personal.html'));
});

app.get('/review', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'review.html'));
});

app.get('/saved', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'saved.html'));
});

app.get('/sign-up', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'sign-up.html'));
});

// API endpoints for JSON files
app.get('/api/chill1', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'json', 'chill1.json'));
});

app.get('/api/cook1', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'json', 'cook1.json'));
});

// Catch-all route for 404 errors (optional)
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});