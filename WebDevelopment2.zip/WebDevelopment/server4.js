const express = require('express');
const path = require('path');
const { engine } = require('express-handlebars');

const app = express();
const port = 3000;

// Set Handlebars as the view engine
app.engine('hbs', engine({
    extname: '.hbs',
    defaultLayout: 'main',
    partialsDir: path.join(__dirname, 'views/partials')  // Register the partials folder
}));

app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Sample data for dynamic rendering
const homepageData = {
    title: 'Cook & Chill',
    nav: ['Home', 'About', 'Contact Us', 'Login', 'Sign Up'],
    about: {
        text: "At Cook & Chill, our purpose is to showcase the best and most interesting aspects of arts and entertainment.",
       // image: '/images/About.webp'
    },
    sections: [
        { text: "Cook Whatever You Want, Anytime You Want!" },
        { text: "Upload Your Own Recipe and Share the Flavor!" },
        { text: "Give Reviews, Get Feedback, and Perfect Your Recipes!" }
    ],
    faq: [
        "How can I upload my own recipe or review?",
        "How do I get feedback on my recipe or review?",
        "What types of recipes and entertainment reviews can I submit?",
        "How do you choose featured recipes or reviews?"
    ],
    footer: {
        email: "info@cookchill.com",
        socialMediaIcons: [
            {
                path1: "M12 22C17.5228 22 22 17.5228 22 12",
                path2: "M8.58815 12.3773L9.45909 11.2956C9.82616 10.8397 10.2799 10.4153 10.3155 9.80826"
            }
        ],
        privacyPolicyLink: "/privacy-policy",
        termsLink: "/terms-and-conditions"
    }
};

// Route to render homepage
app.get('/', (req, res) => {
    res.render('homepage', homepageData);
});

// Start the server
app.listen(port, () => {
    console.log(`App running at http://localhost:${port}`);
});
